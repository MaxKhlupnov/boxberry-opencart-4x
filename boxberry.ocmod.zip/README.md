# boxberry-opencart-4x
Поддержка модуля интеграции сервиса дсотавки boxberry с CMS  OpenCart 4.0

## На данный момент существут интеграциионные модули сервиса доставки Boxberry с Opencart, но они не поддерживают версию 4.
см. так же https://jira.boxberry.ru/servicedesk/customer/portal/38/SERVICE-12249
