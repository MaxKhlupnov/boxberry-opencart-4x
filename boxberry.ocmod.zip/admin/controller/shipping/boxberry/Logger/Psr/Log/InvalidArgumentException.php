<?php

namespace Boxberry\Logger\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
