<?php
$_['heading_title']                 = 'Boxberry';
$_['text_list']                     = 'Посылки';
$_['column_order_id']               = '№ Заказа';
$_['column_im_id']                  = 'Номер отправления';
$_['column_label']                  = 'Ссылка на этикетку/акт';
$_['column_boxberry_to_point']      = 'Пункт выдачи';
$_['column_address']                = 'Выбранный адрес';
$_['column_error']                  = 'Описание ошибки';
$_['entry_order_id']                = '№ Заказа';
$_['entry_im_id']                   = 'Номер отправления';
$_['entry_label']                   = 'Ссылка на этикетку/акт';
$_['entry_error']                   = 'Описание ошибки';
$_['button_parsel_send']            = 'Сформировать акт';
$_['button_parsel_send_print']      = 'Посылки в акте не будут включены в список';
$_['tab_act']                       = 'Акты';