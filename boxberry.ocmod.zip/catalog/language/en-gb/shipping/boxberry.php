<?php
$_['text_title']                                = 'Служба доставки Boxberry';
$_['text_courier_delivery_description']         = 'Boxberry - Курьерская доставка';
$_['text_courier_delivery_prepaid_description'] = 'Boxberry - Курьерская доставка (без н. платежа)';
$_['text_pickup_description']                   = 'Boxberry - До пункта выдачи';
$_['text_pickup_prepaid_description']           = 'Boxberry - до пункта выдачи (без н. платежа)';
